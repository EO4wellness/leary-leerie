# Version Control with Git

This is the repo for [Udacity's Version Control with Git course](). In the course, students will learn version control while learning the basics to intermediate knowledge of Git.

This repo contains the source code of a blog project that will be used throughout the course.

## Table of Contents

* [Instructions](#instructions)
* [Creator](#creators)

## Instructions

* clone the project
* open the index file in a browser

## Creators

* Richard Kalehoff
    - [https://github.com/richardkalehoff](https://github.com/richardkalehoff)
    - [https://twitter.com/richardkalehoff](https://twitter.com/richardkalehoff)

With the help of:

* Colt
* James
* Julia
